import{r as F,j as p,V as R,S as z,c as q}from"./scores-Cl_jFP_1.js";import{B as D,a as j}from"./config-jU6-pJNw.js";import{g as $}from"./settings-DezWZQWT.js";const P=`/* MaterialIQ design tokens — cream fabric · azure · ink · Archivo.
   :root only (no element styles) so this can be injected into a Shadow DOM by the
   content script. Element/base rules live in base.css. */
@import url('https://fonts.googleapis.com/css2?family=Archivo:ital,wdth,wght@0,62..125,100..900&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

:root {
  /* Surfaces (warm cream paper/fabric) */
  --bg-0: #F2EFE9;
  --bg-1: #ECE7DD;
  --surface-card: #FAF8F3;
  --surface-card-2: #E7E2D6;
  --surface-overlay: rgba(22, 24, 26, 0.45);

  /* Ink (near-black bands + dark UI + injected badge) */
  --ink-0: #16181A;
  --ink-1: #1F2226;
  --ink-2: #2A2E33;

  /* Glass (extension panel over retailer pages) */
  --glass-fill: rgba(250, 248, 243, 0.74);
  --glass-fill-strong: rgba(250, 248, 243, 0.88);
  --glass-border: rgba(22, 24, 26, 0.14);
  --glass-blur: 20px;

  /* Borders */
  --border-1: rgba(22, 24, 26, 0.14);
  --border-2: rgba(22, 24, 26, 0.28);
  --border-accent: rgba(0, 119, 230, 0.45);
  --border-inverse: rgba(242, 239, 233, 0.16);
  --border-inverse-2: rgba(242, 239, 233, 0.30);

  /* Text */
  --fg-1: #16181A;
  --fg-2: #5B6066;
  --fg-3: #8D9198;
  --fg-inverse: #F2EFE9;
  --fg-inverse-2: #A9ADA6;

  /* Accent — azure. The ONLY brand hue. */
  --accent: #0077E6;
  --accent-bright: #2B93F2;
  --accent-dim: #005BB4;
  --accent-tint: rgba(0, 119, 230, 0.10);
  --accent-tint-2: rgba(0, 119, 230, 0.18);

  /* Score semantics — pigment, not neon */
  --score-neutral: #16181A;
  --score-high: #0E7C4A;
  --score-high-tint: rgba(14, 124, 74, 0.10);
  --score-low: #C0392B;
  --score-low-tint: rgba(192, 57, 43, 0.10);

  /* Aliases */
  --text-body: var(--fg-1);
  --text-muted: var(--fg-2);
  --text-link: var(--accent);
  --surface-page: var(--bg-0);
  --surface-raised: var(--surface-card);
  --focus-ring: 0 0 0 2px var(--bg-0), 0 0 0 4px var(--accent);

  /* Type */
  --font-sans: 'Archivo', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
  --font-display: 'Archivo', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, 'SF Mono', Menlo, monospace;
  --display-stretch: 125%;
  --display-weight: 800;
  --display-tracking: -0.01em;
  --text-xs: 11px;
  --text-sm: 13px;
  --text-md: 15px;
  --text-lg: 18px;
  --text-xl: 24px;
  --text-2xl: 34px;
  --text-3xl: 52px;
  --text-4xl: 76px;
  --text-score: 44px;
  --text-score-sm: 20px;
  --tracking-label: 0.12em;
  --tracking-caps: 0.08em;
  --tracking-body: -0.005em;
  --leading-tight: 0.95;
  --leading-snug: 1.15;
  --leading-body: 1.5;

  /* Spacing / radii / controls */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;
  --space-24: 96px;
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-pill: 999px;
  --control-h-sm: 28px;
  --control-h-md: 36px;
  --control-h-lg: 44px;
  --popup-w: 380px;
  --page-max-w: 1180px;

  /* Texture */
  --texture-grain: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='matrix' values='0 0 0 0 0.09 0 0 0 0 0.09 0 0 0 0 0.10 0 0 0 0.055 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  --texture-grain-light: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='matrix' values='0 0 0 0 0.95 0 0 0 0 0.94 0 0 0 0 0.91 0 0 0 0.045 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");

  /* Elevation — soft print shadows, never glow */
  --shadow-card: 0 1px 0 rgba(22, 24, 26, 0.04), 0 8px 24px rgba(22, 24, 26, 0.07);
  --shadow-pop: 0 16px 48px rgba(22, 24, 26, 0.16);
  --shadow-glass: 0 2px 4px rgba(22, 24, 26, 0.06), 0 24px 64px rgba(22, 24, 26, 0.22);

  /* Motion */
  --ease-out: cubic-bezier(0.2, 0, 0, 1);
  --dur-fast: 120ms;
  --dur-ui: 160ms;
  --dur-slow: 200ms;
  --dur-reveal: 550ms;
  --transition-ui: all var(--dur-ui) var(--ease-out);
}
`,L=[{fiber:"organic-cotton",pattern:/organic\s+cotton/i},{fiber:"recycled-polyester",pattern:/recycled\s+polyester/i},{fiber:"pima-cotton",pattern:/(pima|supima)\s*(cotton)?/i},{fiber:"combed-cotton",pattern:/combed\s+cotton/i},{fiber:"merino",pattern:/merino/i},{fiber:"cashmere",pattern:/cashmere/i},{fiber:"wool",pattern:/\bwool\b/i},{fiber:"linen",pattern:/\blinen\b/i},{fiber:"silk",pattern:/\bsilk\b/i},{fiber:"tencel",pattern:/tencel|lyocell/i},{fiber:"modal",pattern:/\bmodal\b/i},{fiber:"bamboo",pattern:/bamboo/i},{fiber:"viscose",pattern:/viscose|rayon/i},{fiber:"polyester",pattern:/polyester/i},{fiber:"nylon",pattern:/nylon|polyamide/i},{fiber:"elastane",pattern:/elastane|spandex|lycra/i},{fiber:"acrylic",pattern:/acrylic/i},{fiber:"bonded-leather",pattern:/bonded\s+leather|pu\s+leather/i},{fiber:"cotton",pattern:/cotton/i}];function E(e){for(const{fiber:t,pattern:n}of L)if(n.test(e))return t;return null}function O(e){const t=[],n=/(\d{1,3})\s*%\s*([A-Za-z][A-Za-z\s\-]*?)(?=(?:[,;/·•]|\band\b|\d{1,3}\s*%|$))/g;let s;for(;(s=n.exec(e))!==null;){const o=parseInt(s[1],10),c=E(s[2]);c&&o>0&&o<=100&&t.push({fiber:c,percent:o,raw:s[0].trim()})}if(!t.length){const o=/([A-Za-z][A-Za-z\s\-]{1,24}?)\s*(\d{1,3})\s*%/g;let c;for(;(c=o.exec(e))!==null;){const l=E(c[1]),f=parseInt(c[2],10);l&&f>0&&f<=100&&t.push({fiber:l,percent:f,raw:c[0].trim()})}}if(!t.length){const o=E(e);o&&t.push({fiber:o,percent:100,raw:e.trim().slice(0,60)})}const r=[],i=new Set;for(const o of t){const c=`${o.fiber}:${o.percent}`;i.has(c)||(i.add(c),r.push(o))}const a=new Map;for(const o of r){const c=a.get(o.fiber);c?c.percent=Math.min(100,c.percent+o.percent):a.set(o.fiber,{...o})}return[...a.values()]}function U(e){const t=e.match(/(\d{2,4})\s*(?:gsm|g\/m²|g\/m2|g\.?s\.?m)/i);if(t){const n=parseInt(t[1],10);if(n>=60&&n<=600)return n}return null}function N(e){return/ring[-\s]?spun/i.test(e)?"ring-spun":/combed/i.test(e)?"combed":/open[-\s]?end/i.test(e)?"open-end":"unknown"}function W(e){const t=[/double[-\s]?stitch\w*/i,/triple[-\s]?stitch\w*/i,/flat[-\s]?lock\w*/i,/link(?:ed)?[-\s]?seam\w*/i,/fully[-\s]?fashioned/i,/reinforced[\w\s]*/i,/side[-\s]?seam\w*/i,/taped\s+(?:neck|shoulder)\w*/i],n=new Set;for(const s of t){const r=e.match(s);r&&n.add(r[0].trim())}return[...n]}function B(e){const t=e.replace(/,/g,"").match(/(?:[$£€]|USD|GBP|EUR)?\s*(\d{1,5}(?:\.\d{1,2})?)/);if(!t)return null;const n=parseFloat(t[1]);return Number.isFinite(n)&&n>0?n:null}function Q(e){return/\b(t[-\s]?shirt|tee|top|polo)\b/i.test(e)?"tshirt":/\b(sweater|knit|jumper|cardigan|pullover|crew)\b/i.test(e)?"knit":"unknown"}function G(e){const t=e.querySelectorAll('script[type="application/ld+json"]');for(const n of Array.from(t)){let s;try{s=JSON.parse(n.textContent||"")}catch{continue}const r=Array.isArray(s)?s:s["@graph"]??[s];for(const i of r){const a=i?.["@type"];if(!(a==="Product"||Array.isArray(a)&&a.includes("Product")))continue;const l=[].concat(i.offers??[])[0]??{},f=l.price!=null?B(String(l.price)):null;return{name:typeof i.name=="string"?i.name:void 0,material:typeof i.material=="string"?i.material:void 0,description:typeof i.description=="string"?i.description:void 0,price:f,currency:typeof l.priceCurrency=="string"?l.priceCurrency:void 0}}}return null}function C(e,t){for(const n of t){const r=e.querySelector(`meta[property="${n}"], meta[name="${n}"]`)?.getAttribute("content");if(r)return r}return null}function H(e){const t=/(composition|material|fabric|cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic|gsm|g\/m|ring[-\s]?spun|stitch|seam|knit|fashioned|reinforced|taped|% )/i,n=[],s=e.querySelectorAll("li, dd, dt, td, th, p, span, div");for(const r of Array.from(s)){if(n.length>40)break;const i=(r.textContent||"").replace(/\s+/g," ").trim();i.length>4&&i.length<240&&t.test(i)&&n.push(i)}return Array.from(new Set(n)).join(" · ").slice(0,4e3)}function Y(e){const t=new Set,n=e.querySelectorAll('script:not([type="application/ld+json"])'),s=/(\d{1,3}\s*%\s*[A-Za-z][A-Za-z\s\-]{2,20}|\d{2,4}\s*(?:gsm|g\/m²|g\/m2)|ring[-\s]?spun|open[-\s]?end|combed)/gi;for(const r of Array.from(n)){const i=r.textContent||"";if(i.length<20||i.length>5e5||!/cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic|gsm|composition/i.test(i))continue;let a,o=0;for(;(a=s.exec(i))!==null&&o<20;)t.add(a[0].replace(/\s+/g," ").trim()),o++;if(t.size>40)break}return Array.from(t).join(" · ").slice(0,2e3)}function S(e,t,n={}){const s=new URL(t).hostname,r=G(e),i=n.title||r?.name||C(e,["og:title"])||e.querySelector("h1")?.textContent?.trim()||e.title||"Unknown product",a=n.priceText||(r?.price!=null?String(r.price):null)||C(e,["product:price:amount","og:price:amount"]),o=a?B(a):null,c=r?.currency||C(e,["product:price:currency","og:price:currency"])||"USD",l=H(e),f=!/(cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic)/i.test(`${n.specText??""} ${r?.material??""} ${l}`),u=[n.specText,r?.material,r?.description,l,f?Y(e):""].filter(Boolean).join(" · "),h=O(u),x=U(u),d=N(u),y=W(u),m=Q(`${i} ${u}`),v=[];h.length||v.push("Fiber content not found on this page"),x==null&&v.push("Fabric weight (GSM) not listed"),o==null&&v.push("Price not found");let b=.3;return h.length&&(b+=.35),o!=null&&(b+=.2),x!=null&&(b+=.1),(d!=="unknown"||y.length)&&(b+=.05),!h.length&&o==null?null:{title:i,retailer:s,url:t,price:o,currency:c,category:m,composition:h,gsm:x,yarn:d,origin:null,constructionSignals:y,extractionConfidence:Math.min(1,b),notes:v}}function V(e){return e.replace(/\\u003c/gi,"<").replace(/\\u003e/gi,">").split(/<|\\n/)[0].trim()}function Z(e,t){const n=e.documentElement?.outerHTML??"",s=e.querySelector('meta[property="og:title"]')?.getAttribute("content"),r=n.match(/"name"\s*:\s*"([^"]+?)"\s*,\s*"prices?"/),i=(s||r?.[1]||e.querySelector("h1")?.textContent||"").replace(/\s*\|\s*UNIQLO.*$/i,"").trim()||null,o=n.match(/"prices"\s*:\s*\{\s*"base"\s*:\s*\{[\s\S]{0,200}?"value"\s*:\s*([0-9]+(?:\.[0-9]+)?)/)?.[1]||e.querySelector('[class*="price"] [class*="value"], span[class*="price"], [data-testid*="price"]')?.textContent||null,c=n.match(/"composition"\s*:\s*"([^"]+)"/),l=Array.from(e.querySelectorAll('[class*="accordion"], [class*="detail"], section, dl')).map(u=>u.textContent?.replace(/\s+/g," ").trim()||"").filter(u=>/(cotton|polyester|wool|material|composition|%)/i.test(u)).join(" · "),f=c?V(c[1]):l;return S(e,t,{title:i,priceText:o,specText:f})}function I(e,t){for(const n of t){const r=e.querySelector(n)?.textContent?.replace(/\s+/g," ").trim();if(r)return r}return null}function K(e,t){const n=e.documentElement?.outerHTML??"",r=(e.querySelector('meta[property="og:title"]')?.getAttribute("content")||I(e,["h1"])||"").replace(/\s*[|·]\s*H&?M.*$/i,"").trim()||null,i=e.querySelector('meta[property="product:price:amount"], meta[property="og:price:amount"]')?.getAttribute("content")||n.match(/"(?:price|whitePrice|redPrice)"\s*:\s*\{[^{}]*?"value"\s*:\s*([0-9]+(?:\.[0-9]+)?)/)?.[1]||I(e,['[class*="price"] [class*="value"]','span[class*="price"]','[data-testid*="price"]']),a=n.match(/"composition"\s*:\s*"([^"]+)"/i)||n.match(/Composition[^%<]{0,30}(\d{1,3}\s*%[^<"]{0,60})/i),o=Array.from(e.querySelectorAll('[class*="composition"], [class*="materials"], [class*="ProductDetails"], [class*="detail"], section, dl')).map(l=>l.textContent?.replace(/\s+/g," ").trim()||"").filter(l=>/(cotton|polyester|wool|elastane|viscose|composition|%)/i.test(l)).join(" · "),c=[a?a[1]:"",o].filter(Boolean).join(" · ")||void 0;return S(e,t,{title:r,priceText:i,specText:c})}function M(e,t){for(const n of t){const r=e.querySelector(n)?.textContent?.replace(/\s+/g," ").trim();if(r)return r}return null}function X(e,t){const n=M(e,["#productTitle","h1#title","h1.product-title-word-break","h1"]),s=M(e,["#corePriceDisplay_desktop_feature_div .a-price .a-offscreen","#corePrice_feature_div .a-price .a-offscreen","#apex_desktop .a-price .a-offscreen",".priceToPay .a-offscreen","#tp_price_block_total_price_ww .a-offscreen",'span[data-a-color="price"] .a-offscreen',".a-price .a-offscreen","#priceblock_ourprice","#price_inside_buybox"]);let r=Array.from(e.querySelectorAll("#productOverview_feature_div tr, #productFactsDesktopExpander li, #detailBullets_feature_div li, #productDetails_techSpec_section_1 tr, #productDetails_detailBullets_sections1 tr, #feature-bullets li, #productDescription, .prodDetSectionEntry, .a-expander-content li")).map(o=>o.textContent?.replace(/\s+/g," ").trim()||"").filter(o=>o.length>3&&o.length<240&&/(material|fabric|cotton|polyester|wool|linen|viscose|nylon|acrylic|composition|gsm|%)/i.test(o)).join(" · ").slice(0,4e3);const i="cotton|polyester|wool|elastane|spandex|viscose|rayon|linen|nylon|acrylic|modal|cashmere|silk";if(!new RegExp(i,"i").test(r)){const o=(e.body?.textContent||"").replace(/\s+/g," "),c=o.match(new RegExp(`(\\d{1,3}\\s*%\\s*(?:${i})(?:\\s*[,/]?\\s*\\d{1,3}\\s*%\\s*[a-z]+)*)`,"i"))||o.match(new RegExp(`((?:${i})\\s*\\d{1,3}\\s*%(?:\\s*[,/]?\\s*[a-z]+\\s*\\d{1,3}\\s*%)*)`,"i"));c&&(r=[r,c[1]].filter(Boolean).join(" · "))}const a=s||(e.body?.textContent||"").match(/\$\s?\d{1,4}\.\d{2}/)?.[0]||null;return S(e,t,{title:n,priceText:a,specText:r})}const J=[{test:/(^|\.)uniqlo\.com$/i,extract:Z},{test:/(^|\.)hm\.com$/i,extract:K},{test:/(^|\.)amazon\.com$/i,extract:X}];function ee(e=document,t=location.href){const n=new URL(t).hostname,s=J.find(r=>r.test.test(n));try{return(s?.extract??S)(e,t)}catch(r){return console.warn("[MaterialIQ] extraction failed:",r),null}}const te=['[data-hook="review-body"]','[class*="review-text"]','[class*="reviewText"]','[class*="review-content"]','[itemprop="reviewBody"]','[class*="review"] p'];function ne(e=document){const t=new Set;for(const n of te){for(const s of Array.from(e.querySelectorAll(n))){const r=(s.textContent||"").replace(/\s+/g," ").trim();if(r.length>=20&&r.length<=1500&&t.add(r),t.size>=200)return[...t]}if(t.size>=40)break}return[...t]}async function re(e,t,n){if(t.length===0)return null;const s=new AbortController,r=setTimeout(()=>s.abort(),12e3);try{const i=await fetch(`${D}/api/summarize`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({title:e,reviews:t,url:n}),signal:s.signal});if(!i.ok)return null;const a=await i.json();return{count:a.count,pros:a.pros??[],cons:a.cons??[],durabilitySignal:a.durabilitySignal}}catch{return null}finally{clearTimeout(r)}}const oe={worth:"var(--score-high)",fair:"var(--fg-inverse-2)",skip:"var(--score-low)"},ie={worth:"Worth it",fair:"Fair price",skip:"Skip it"};function se({analysis:e,docsUrl:t}){const[n,s]=F.useState(!1),r=e.factors.filter(i=>i.key!=="value").slice(0,3);return p.jsxs("span",{style:{position:"relative",display:"inline-block",fontFamily:"var(--font-sans)"},children:[p.jsxs("button",{onClick:()=>s(!n),style:{display:"inline-flex",alignItems:"center",gap:8,height:30,padding:"0 12px",background:"var(--ink-0)",color:"var(--fg-inverse)",border:"1px solid "+(n?"var(--accent)":"var(--ink-0)"),borderRadius:"var(--radius-sm)",cursor:"pointer",fontFamily:"var(--font-sans)",fontSize:12,fontWeight:700,boxShadow:"0 2px 8px rgba(22,24,26,0.18)",transition:"var(--transition-ui)"},children:[p.jsx("span",{style:{width:7,height:7,borderRadius:"50%",background:oe[e.verdict]}}),p.jsx("span",{style:{fontFamily:"var(--font-mono)",fontWeight:600},children:e.overall.toFixed(1)}),p.jsx("span",{style:{color:"var(--fg-inverse-2)",fontWeight:500},children:ie[e.verdict]}),p.jsx("span",{style:{color:"var(--accent-bright)",fontFamily:"var(--font-display)",fontStretch:"125%",fontWeight:800},children:"IQ"})]}),n&&p.jsxs("div",{style:{position:"absolute",top:"calc(100% + 10px)",left:0,width:300,zIndex:2147483647,background:"var(--glass-fill-strong)",backdropFilter:"blur(var(--glass-blur)) saturate(1.15)",WebkitBackdropFilter:"blur(var(--glass-blur)) saturate(1.15)",border:"1px solid var(--glass-border)",borderRadius:"var(--radius-xl)",boxShadow:"var(--shadow-glass)",padding:16,color:"var(--fg-1)",textAlign:"left"},children:[p.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12},children:[p.jsxs("span",{style:{fontFamily:"var(--font-display)",fontStretch:"125%",fontWeight:800,fontSize:13,textTransform:"uppercase"},children:["Material",p.jsx("span",{style:{color:"var(--accent)"},children:"IQ"})]}),p.jsx(R,{verdict:e.verdict})]}),p.jsx("p",{style:{margin:"0 0 12px",fontSize:12,color:"var(--fg-2)",lineHeight:1.5},children:e.verdictCopy}),p.jsx("div",{style:{display:"grid",gap:10},children:r.map(i=>p.jsx(z,{label:i.label,value:i.value,max:i.max},i.key))}),p.jsx("a",{href:t,target:"_blank",rel:"noreferrer",style:{display:"block",fontSize:12,marginTop:12,color:"var(--accent)"},children:"Open full scorecard →"})]})]})}let g=null,w;const ce=chrome.runtime.getURL("src/options/index.html")+"#methodology",ae=P.replace(/:root/g,":host");function le(){if(document.getElementById("miq-fonts"))return;const e=document.createElement("link");e.id="miq-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Archivo:wght@400..800&family=IBM+Plex+Mono:wght@400;500;600&display=swap",document.head.appendChild(e)}function pe(e){if(e==null)return null;const t=e.toFixed(2),n=String(Math.round(e)),s=document.querySelectorAll('span, div, p, b, strong, ins, bdi, [class*="price" i], [data-testid*="price" i], [itemprop="price"]');let r=null,i=1/0;for(const a of Array.from(s)){const o=(a.textContent||"").replace(/\s+/g,"");if(!o||o.length>24)continue;(o.includes(t)||/[$£€]/.test(o)&&o.replace(/[^\d.]/g,"").startsWith(n))&&o.length<i&&(r=a,i=o.length)}return r}let k=null;function T(){k?.(),k=null,document.getElementById("miq-badge-host")?.remove()}function ue(e){T(),le();const t=document.createElement("span");t.id="miq-badge-host",t.style.position="absolute",t.style.top="-9999px",t.style.zIndex="2147483647",document.body.appendChild(t);const n=t.attachShadow({mode:"open"}),s=document.createElement("style");s.textContent=ae+":host{all:initial;}",n.appendChild(s);const r=document.createElement("div");n.appendChild(r);const i=q(r);i.render(p.jsx(F.StrictMode,{children:p.jsx(se,{analysis:e,docsUrl:ce})}));const a=130,o=32;let c=null;const l=()=>{(!c||!c.isConnected)&&(c=pe(e.product.price));const d=c?.isConnected?c.getBoundingClientRect():null;if(d&&(d.width||d.height)){t.style.position="absolute",t.style.right=t.style.bottom="";let y,m;window.innerWidth-d.right>a+16?(y=window.scrollY+d.top+Math.max(0,(d.height-o)/2),m=window.scrollX+d.right+10):(y=window.scrollY+d.bottom+6,m=window.scrollX+d.left),m=Math.max(window.scrollX+8,Math.min(m,window.scrollX+window.innerWidth-a-8)),t.style.top=`${y}px`,t.style.left=`${m}px`}else t.style.position="fixed",t.style.top=t.style.left="",t.style.right="20px",t.style.bottom="20px"};let f=0;const u=()=>{cancelAnimationFrame(f),f=requestAnimationFrame(l)};l();const h=[300,900,1800,3200].map(d=>window.setTimeout(l,d)),x=window.setInterval(l,2e3);window.addEventListener("scroll",u,{passive:!0}),window.addEventListener("resize",u,{passive:!0}),k=()=>{h.forEach(clearTimeout),clearInterval(x),window.removeEventListener("scroll",u),window.removeEventListener("resize",u),cancelAnimationFrame(f),i.unmount()}}async function A(e=0){const t=await $(),n=ee();if(!n||n.extractionConfidence<t.minConfidence){w=n?"low-confidence":"no-product",e<5&&!g&&setTimeout(()=>A(e+1),800);return}const s=j(n);if(g=s,chrome.runtime.sendMessage({type:"MIQ_VERDICT",verdict:s.verdict}).catch(()=>{}),t.showInlineBadge)try{ue(s)}catch(r){console.warn("[MaterialIQ] badge mount failed:",r)}t.reviewSummaries&&de(n)}async function de(e){const t=ne();if(t.length===0)return;const n=await re(e.title,t,e.url);if(!n)return;g=j({...e,reviews:n})}chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="MIQ_GET_ANALYSIS"?(n({type:"MIQ_ANALYSIS",analysis:g,reason:w}),!0):(e.type==="MIQ_RECHECK"&&(T(),g=null,w=void 0,A().then(()=>n({type:"MIQ_ANALYSIS",analysis:g,reason:w}))),!0));let _=location.href;new MutationObserver(()=>{location.href!==_&&(_=location.href,g=null,w=void 0,T(),setTimeout(()=>A(),800))}).observe(document.body,{childList:!0,subtree:!0});A();
