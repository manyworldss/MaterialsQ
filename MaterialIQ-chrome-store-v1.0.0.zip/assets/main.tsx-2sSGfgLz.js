import{r as E,j as u,V as U,S as N,c as W}from"./scores-Bl7Dju0F.js";import{B as H,a as $}from"./config-xbb-_z2I.js";import{g as Q}from"./settings-C2PmzWEK.js";const G=`/* MaterialIQ design tokens — cream fabric · azure · ink · Archivo.
   :root only (no element styles) so this can be injected into a Shadow DOM by the
   content script. Element/base rules live in base.css. */
@import url('https://fonts.googleapis.com/css2?family=Archivo:ital,wdth,wght@0,62..125,100..900&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

:root {
  /* Surfaces (warm cream paper/fabric) */
  --bg-0: #F2EFE9;
  --bg-1: #ECE7DD;
  --surface-card: #FAF8F3;
  --surface-card-2: #E7E2D6;
  --surface-overlay: rgba(22, 24, 26, 0.45);

  /* Ink (near-black bands + dark UI + injected badge) */
  --ink-0: #16181A;
  --ink-1: #1F2226;
  --ink-2: #2A2E33;

  /* Glass (extension panel over retailer pages) */
  --glass-fill: rgba(250, 248, 243, 0.74);
  --glass-fill-strong: rgba(250, 248, 243, 0.88);
  --glass-border: rgba(22, 24, 26, 0.14);
  --glass-blur: 20px;

  /* Borders */
  --border-1: rgba(22, 24, 26, 0.14);
  --border-2: rgba(22, 24, 26, 0.28);
  --border-accent: rgba(0, 119, 230, 0.45);
  --border-inverse: rgba(242, 239, 233, 0.16);
  --border-inverse-2: rgba(242, 239, 233, 0.30);

  /* Text */
  --fg-1: #16181A;
  --fg-2: #5B6066;
  --fg-3: #8D9198;
  --fg-inverse: #F2EFE9;
  --fg-inverse-2: #A9ADA6;

  /* Accent — azure. The ONLY brand hue. */
  --accent: #0077E6;
  --accent-bright: #2B93F2;
  --accent-dim: #005BB4;
  --accent-tint: rgba(0, 119, 230, 0.10);
  --accent-tint-2: rgba(0, 119, 230, 0.18);

  /* Score semantics — pigment, not neon */
  --score-neutral: #16181A;
  --score-high: #0E7C4A;
  --score-high-tint: rgba(14, 124, 74, 0.10);
  --score-low: #C0392B;
  --score-low-tint: rgba(192, 57, 43, 0.10);

  /* Aliases */
  --text-body: var(--fg-1);
  --text-muted: var(--fg-2);
  --text-link: var(--accent);
  --surface-page: var(--bg-0);
  --surface-raised: var(--surface-card);
  --focus-ring: 0 0 0 2px var(--bg-0), 0 0 0 4px var(--accent);

  /* Type */
  --font-sans: 'Archivo', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
  --font-display: 'Archivo', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, 'SF Mono', Menlo, monospace;
  --display-stretch: 125%;
  --display-weight: 800;
  --display-tracking: -0.01em;
  --text-xs: 11px;
  --text-sm: 13px;
  --text-md: 15px;
  --text-lg: 18px;
  --text-xl: 24px;
  --text-2xl: 34px;
  --text-3xl: 52px;
  --text-4xl: 76px;
  --text-score: 44px;
  --text-score-sm: 20px;
  --tracking-label: 0.12em;
  --tracking-caps: 0.08em;
  --tracking-body: -0.005em;
  --leading-tight: 0.95;
  --leading-snug: 1.15;
  --leading-body: 1.5;

  /* Spacing / radii / controls */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;
  --space-24: 96px;
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-pill: 999px;
  --control-h-sm: 28px;
  --control-h-md: 36px;
  --control-h-lg: 44px;
  --popup-w: 380px;
  --page-max-w: 1180px;

  /* Texture */
  --texture-grain: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='matrix' values='0 0 0 0 0.09 0 0 0 0 0.09 0 0 0 0 0.10 0 0 0 0.055 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  --texture-grain-light: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='matrix' values='0 0 0 0 0.95 0 0 0 0 0.94 0 0 0 0 0.91 0 0 0 0.045 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");

  /* Elevation — soft print shadows, never glow */
  --shadow-card: 0 1px 0 rgba(22, 24, 26, 0.04), 0 8px 24px rgba(22, 24, 26, 0.07);
  --shadow-pop: 0 16px 48px rgba(22, 24, 26, 0.16);
  --shadow-glass: 0 2px 4px rgba(22, 24, 26, 0.06), 0 24px 64px rgba(22, 24, 26, 0.22);

  /* Motion */
  --ease-out: cubic-bezier(0.2, 0, 0, 1);
  --dur-fast: 120ms;
  --dur-ui: 160ms;
  --dur-slow: 200ms;
  --dur-reveal: 550ms;
  --transition-ui: all var(--dur-ui) var(--ease-out);
}
`,Z=[{fiber:"organic-cotton",pattern:/organic\s+cotton/i},{fiber:"recycled-polyester",pattern:/recycled\s+polyester/i},{fiber:"pima-cotton",pattern:/(pima|supima)\s*(cotton)?/i},{fiber:"combed-cotton",pattern:/combed\s+cotton/i},{fiber:"merino",pattern:/merino/i},{fiber:"cashmere",pattern:/cashmere/i},{fiber:"wool",pattern:/\bwool\b/i},{fiber:"linen",pattern:/\blinen\b/i},{fiber:"silk",pattern:/\bsilk\b/i},{fiber:"tencel",pattern:/tencel|lyocell/i},{fiber:"modal",pattern:/\bmodal\b/i},{fiber:"bamboo",pattern:/bamboo/i},{fiber:"viscose",pattern:/viscose|rayon/i},{fiber:"polyester",pattern:/polyester/i},{fiber:"nylon",pattern:/nylon|polyamide/i},{fiber:"elastane",pattern:/elastane|spandex|lycra/i},{fiber:"acrylic",pattern:/acrylic/i},{fiber:"bonded-leather",pattern:/bonded\s+leather|pu\s+leather/i},{fiber:"cotton",pattern:/cotton/i}];function k(e){for(const{fiber:t,pattern:n}of Z)if(n.test(e))return t;return null}function V(e){const t=[],n=/(\d{1,3})\s*%\s*([A-Za-z][A-Za-z\s\-]*?)(?=(?:[,;/·•]|\band\b|\d{1,3}\s*%|$))/g;let i;for(;(i=n.exec(e))!==null;){const o=parseInt(i[1],10),c=k(i[2]);c&&o>0&&o<=100&&t.push({fiber:c,percent:o,raw:i[0].trim()})}if(!t.length){const o=/([A-Za-z][A-Za-z\s\-]{1,24}?)\s*(\d{1,3})\s*%/g;let c;for(;(c=o.exec(e))!==null;){const l=k(c[1]),d=parseInt(c[2],10);l&&d>0&&d<=100&&t.push({fiber:l,percent:d,raw:c[0].trim()})}}if(!t.length){const o=k(e);o&&t.push({fiber:o,percent:100,raw:e.trim().slice(0,60)})}const r=[],s=new Set;for(const o of t){const c=`${o.fiber}:${o.percent}`;s.has(c)||(s.add(c),r.push(o))}const a=new Map;for(const o of r){const c=a.get(o.fiber);c?c.percent=Math.min(100,c.percent+o.percent):a.set(o.fiber,{...o})}return[...a.values()]}function Y(e){const t=e.match(/(\d{2,4})\s*(?:gsm|g\/m²|g\/m2|g\.?s\.?m)/i);if(t){const n=parseInt(t[1],10);if(n>=60&&n<=600)return n}return null}function K(e){return/ring[-\s]?spun/i.test(e)?"ring-spun":/combed/i.test(e)?"combed":/open[-\s]?end/i.test(e)?"open-end":"unknown"}function X(e){const t=[/double[-\s]?stitch\w*/i,/triple[-\s]?stitch\w*/i,/flat[-\s]?lock\w*/i,/link(?:ed)?[-\s]?seam\w*/i,/fully[-\s]?fashioned/i,/reinforced[\w\s]*/i,/side[-\s]?seam\w*/i,/taped\s+(?:neck|shoulder)\w*/i],n=new Set;for(const i of t){const r=e.match(i);r&&n.add(r[0].trim())}return[...n]}function L(e){const t=e.replace(/,/g,"").match(/(?:[$£€]|USD|GBP|EUR)?\s*(\d{1,5}(?:\.\d{1,2})?)/);if(!t)return null;const n=parseFloat(t[1]);return Number.isFinite(n)&&n>0?n:null}function J(e){return/\b(t[-\s]?shirt|tee|top|polo)\b/i.test(e)?"tshirt":/\b(sweater|knit|jumper|cardigan|pullover|crew)\b/i.test(e)?"knit":"unknown"}const F=e=>(e??"").toLowerCase().replace(/[^a-z0-9]/g,"");function ee(e,t){const n=[],i=e.querySelectorAll('script[type="application/ld+json"]');for(const r of Array.from(i)){let s;try{s=JSON.parse(r.textContent||"")}catch{continue}const a=Array.isArray(s)?s:s["@graph"]??[s];for(const o of a){const c=o?.["@type"];if(!(c==="Product"||Array.isArray(c)&&c.includes("Product")))continue;const f=[].concat(o.offers??[])[0]??{},p=f.price!=null?L(String(f.price)):null;n.push({name:typeof o.name=="string"?o.name:void 0,material:typeof o.material=="string"?o.material:void 0,description:typeof o.description=="string"?o.description:void 0,price:p,currency:typeof f.priceCurrency=="string"?f.priceCurrency:void 0})}}if(!n.length)return null;if(t){const r=F(t),s=n.find(a=>{const o=F(a.name);return o&&(o===r||r.length>=8&&(o.includes(r.slice(0,16))||r.includes(o.slice(0,16))))});if(s)return s}return n[0]}const te=/(recommend|related|you[-\s]?may|similar|recently[-\s]?viewed|also[-\s]?(bought|viewed|like|purchased)|complete[-\s]?the[-\s]?look|shop[-\s]?the[-\s]?look|customers[-\s]?also|cross[-\s]?sell|upsell|carousel|slider|suggest|more[-\s]?like|pairs[-\s]?with|breadcrumb|site[-\s]?nav|megamenu)/i;function O(e,t){const n=t.parentElement;for(let i=e;i&&i!==n;i=i.parentElement){const r=i.tagName;if(r==="NAV"||r==="FOOTER")return!0;const s=`${i.id} ${i.getAttribute("class")??""} ${i.getAttribute("data-testid")??""} ${i.getAttribute("aria-label")??""}`;if(te.test(s))return!0}return!1}function _(e){const t=e.querySelector('main, [role="main"]');return t&&(t.querySelector("h1")||t.querySelector('[itemprop="name"]'))?t:e.body||e.documentElement}function T(e,t){for(const n of t){const r=e.querySelector(`meta[property="${n}"], meta[name="${n}"]`)?.getAttribute("content");if(r)return r}return null}function ne(e){const t=/(composition|material|fabric|cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic|gsm|g\/m|ring[-\s]?spun|stitch|seam|knit|fashioned|reinforced|taped|% )/i,n=[],i=e.querySelectorAll("li, dd, dt, td, th, p, span, div");for(const r of Array.from(i)){if(n.length>40)break;if(O(r,e))continue;const s=(r.textContent||"").replace(/\s+/g," ").trim();s.length>4&&s.length<240&&t.test(s)&&n.push(s)}return Array.from(new Set(n)).join(" · ").slice(0,4e3)}function re(e){const t=new Set,n=e.querySelectorAll('script:not([type="application/ld+json"])'),i=/(\d{1,3}\s*%\s*[A-Za-z][A-Za-z\s\-]{2,20}|\d{2,4}\s*(?:gsm|g\/m²|g\/m2)|ring[-\s]?spun|open[-\s]?end|combed)/gi;for(const r of Array.from(n)){const s=r.textContent||"";if(s.length<20||s.length>5e5||!/cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic|gsm|composition/i.test(s))continue;let a,o=0;for(;(a=i.exec(s))!==null&&o<20;)t.add(a[0].replace(/\s+/g," ").trim()),o++;if(t.size>40)break}return Array.from(t).join(" · ").slice(0,2e3)}function A(e,t,n={}){const i=new URL(t).hostname,r=n.title||T(e,["og:title"])||e.querySelector("h1")?.textContent?.trim()||e.title||"",s=ee(e,r),a=n.title||s?.name||r||"Unknown product",o=n.priceText||(s?.price!=null?String(s.price):null)||T(e,["product:price:amount","og:price:amount"]),c=o?L(o):null,l=s?.currency||T(e,["product:price:currency","og:price:currency"])||"USD",d=/(cotton|polyester|wool|linen|viscose|cashmere|nylon|acrylic|elastane|spandex|modal|silk|bamboo)/i,f=[n.specText,s?.material].filter(Boolean).join(" · ");let p;if(d.test(f))p=f;else{const M=ne(_(e)),P=!d.test(`${s?.material??""} ${M}`);p=[n.specText,s?.material,s?.description,M,P?re(e):""].filter(Boolean).join(" · ")}const h=V(p),y=Y(p),m=K(p),w=X(p),b=J(`${a} ${p}`),S=[];h.length||S.push("Fiber content not found on this page"),y==null&&S.push("Fabric weight (GSM) not listed"),c==null&&S.push("Price not found");let x=.3;return h.length&&(x+=.35),c!=null&&(x+=.2),y!=null&&(x+=.1),(m!=="unknown"||w.length)&&(x+=.05),!h.length&&c==null?null:{title:a,retailer:i,url:t,price:c,currency:l,category:b,composition:h,gsm:y,yarn:m,origin:null,constructionSignals:w,extractionConfidence:Math.min(1,x),notes:S}}function oe(e){return e.replace(/\\u003c/gi,"<").replace(/\\u003e/gi,">").split(/<|\\n/)[0].trim()}function ie(e,t){const n=e.documentElement?.outerHTML??"",i=e.querySelector('meta[property="og:title"]')?.getAttribute("content"),r=n.match(/"name"\s*:\s*"([^"]+?)"\s*,\s*"prices?"/),s=(i||r?.[1]||e.querySelector("h1")?.textContent||"").replace(/\s*\|\s*UNIQLO.*$/i,"").trim()||null,a=n.match(/"prices"\s*:\s*\{\s*"base"\s*:\s*\{[\s\S]{0,200}?"value"\s*:\s*([0-9]+(?:\.[0-9]+)?)/),o=e.querySelector(".fr-ec-price-text--large")||e.querySelector('main .fr-ec-price-text, [role="main"] .fr-ec-price-text')||e.querySelector('.fr-ec-price-text, [class*="price-text" i], span[class*="price" i], [data-testid*="price" i]'),c=a?.[1]||o?.textContent||null,l=n.match(/"composition"\s*:\s*"([^"]+)"/),d=Array.from(e.querySelectorAll('[class*="accordion"], [class*="detail"], section, dl')).map(p=>p.textContent?.replace(/\s+/g," ").trim()||"").filter(p=>/(cotton|polyester|wool|material|composition|%)/i.test(p)).join(" · "),f=l?oe(l[1]):d;return A(e,t,{title:s,priceText:c,specText:f})}function B(e,t){for(const n of t){const r=e.querySelector(n)?.textContent?.replace(/\s+/g," ").trim();if(r)return r}return null}function se(e,t){const n=e.documentElement?.outerHTML??"",r=(e.querySelector('meta[property="og:title"]')?.getAttribute("content")||B(e,["h1"])||"").replace(/\s*[|·]\s*H&?M.*$/i,"").trim()||null,s=e.querySelector('meta[property="product:price:amount"], meta[property="og:price:amount"]')?.getAttribute("content")||n.match(/"(?:price|whitePrice|redPrice)"\s*:\s*\{[^{}]*?"value"\s*:\s*([0-9]+(?:\.[0-9]+)?)/)?.[1]||B(e,['[class*="price"] [class*="value"]','span[class*="price"]','[data-testid*="price"]']),a=n.match(/"composition"\s*:\s*"([^"]+)"/i),c=(_(e).textContent||"").replace(/\s+/g," ").match(/Composition\s*([A-Za-z][A-Za-z\s]{0,20}?\d{1,3}\s*%(?:\s*[,/]?\s*[A-Za-z][A-Za-z\s]{0,20}?\d{1,3}\s*%)*)/i),l=a?.[1]||c?.[1]||void 0;return A(e,t,{title:r,priceText:s,specText:l})}function j(e,t){for(const n of t){const r=e.querySelector(n)?.textContent?.replace(/\s+/g," ").trim();if(r)return r}return null}function ce(e,t){const n=j(e,["#productTitle","h1#title","h1.product-title-word-break","h1"]),i=j(e,["#corePriceDisplay_desktop_feature_div .a-price .a-offscreen","#corePrice_feature_div .a-price .a-offscreen","#apex_desktop .a-price .a-offscreen",".priceToPay .a-offscreen","#tp_price_block_total_price_ww .a-offscreen",'span[data-a-color="price"] .a-offscreen',".a-price .a-offscreen","#priceblock_ourprice","#price_inside_buybox"]);let r=Array.from(e.querySelectorAll("#productOverview_feature_div tr, #productFactsDesktopExpander li, #detailBullets_feature_div li, #productDetails_techSpec_section_1 tr, #productDetails_detailBullets_sections1 tr, #feature-bullets li, #productDescription, .prodDetSectionEntry, .a-expander-content li")).map(o=>o.textContent?.replace(/\s+/g," ").trim()||"").filter(o=>o.length>3&&o.length<240&&/(material|fabric|cotton|polyester|wool|linen|viscose|nylon|acrylic|composition|gsm|%)/i.test(o)).join(" · ").slice(0,4e3);const s="cotton|polyester|wool|elastane|spandex|viscose|rayon|linen|nylon|acrylic|modal|cashmere|silk";if(!new RegExp(s,"i").test(r)){const o=(e.body?.textContent||"").replace(/\s+/g," "),c=o.match(new RegExp(`(\\d{1,3}\\s*%\\s*(?:${s})(?:\\s*[,/]?\\s*\\d{1,3}\\s*%\\s*[a-z]+)*)`,"i"))||o.match(new RegExp(`((?:${s})\\s*\\d{1,3}\\s*%(?:\\s*[,/]?\\s*[a-z]+\\s*\\d{1,3}\\s*%)*)`,"i"));c&&(r=[r,c[1]].filter(Boolean).join(" · "))}const a=i||(e.body?.textContent||"").match(/\$\s?\d{1,4}\.\d{2}/)?.[0]||null;return A(e,t,{title:n,priceText:a,specText:r})}const ae=[{test:/(^|\.)uniqlo\.com$/i,extract:ie},{test:/(^|\.)hm\.com$/i,extract:se},{test:/(^|\.)amazon\.com$/i,extract:ce}];function le(e=document,t=location.href){const n=new URL(t).hostname,i=ae.find(r=>r.test.test(n));try{return(i?.extract??A)(e,t)}catch(r){return console.warn("[MaterialIQ] extraction failed:",r),null}}const pe=['[data-hook="review-body"]','[class*="review-text"]','[class*="reviewText"]','[class*="review-content"]','[itemprop="reviewBody"]','[class*="review"] p'];function ue(e=document){const t=new Set;for(const n of pe){for(const i of Array.from(e.querySelectorAll(n))){const r=(i.textContent||"").replace(/\s+/g," ").trim();if(r.length>=20&&r.length<=1500&&t.add(r),t.size>=200)return[...t]}if(t.size>=40)break}return[...t]}async function de(e,t,n){if(t.length===0)return null;const i=new AbortController,r=setTimeout(()=>i.abort(),12e3);try{const s=await fetch(`${H}/api/summarize`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({title:e,reviews:t,url:n}),signal:i.signal});if(!s.ok)return null;const a=await s.json();return{count:a.count,pros:a.pros??[],cons:a.cons??[],durabilitySignal:a.durabilitySignal}}catch{return null}finally{clearTimeout(r)}}const fe={worth:"var(--score-high)",fair:"var(--fg-inverse-2)",skip:"var(--score-low)"},me={worth:"Worth it",fair:"Fair price",skip:"Skip it"},z=300,q=220;function ge({analysis:e,docsUrl:t}){const[n,i]=E.useState(!1),[r,s]=E.useState({up:!1,right:!1}),a=E.useRef(null),o=e.factors.filter(l=>l.key!=="value").slice(0,3),c=()=>{if(!n&&a.current){const l=a.current.getBoundingClientRect();s({up:l.bottom+q>window.innerHeight&&l.top-q>0,right:l.left+z>window.innerWidth})}i(l=>!l)};return u.jsxs("span",{style:{position:"relative",display:"inline-block",fontFamily:"var(--font-sans)"},children:[u.jsxs("button",{ref:a,onClick:c,style:{display:"inline-flex",alignItems:"center",gap:8,height:30,padding:"0 12px",background:"var(--ink-0)",color:"var(--fg-inverse)",border:"1px solid "+(n?"var(--accent)":"var(--ink-0)"),borderRadius:"var(--radius-sm)",cursor:"pointer",fontFamily:"var(--font-sans)",fontSize:12,fontWeight:700,boxShadow:"0 2px 8px rgba(22,24,26,0.18)",transition:"var(--transition-ui)"},children:[u.jsx("span",{style:{width:7,height:7,borderRadius:"50%",background:fe[e.verdict]}}),u.jsx("span",{style:{fontFamily:"var(--font-mono)",fontWeight:600},children:e.overall.toFixed(1)}),u.jsx("span",{style:{color:"var(--fg-inverse-2)",fontWeight:500},children:me[e.verdict]}),u.jsx("span",{style:{color:"var(--accent-bright)",fontFamily:"var(--font-display)",fontStretch:"125%",fontWeight:800},children:"IQ"})]}),n&&u.jsxs("div",{style:{position:"absolute",top:r.up?void 0:"calc(100% + 10px)",bottom:r.up?"calc(100% + 10px)":void 0,left:r.right?void 0:0,right:r.right?0:void 0,width:z,zIndex:2147483647,background:"var(--glass-fill-strong)",backdropFilter:"blur(var(--glass-blur)) saturate(1.15)",WebkitBackdropFilter:"blur(var(--glass-blur)) saturate(1.15)",border:"1px solid var(--glass-border)",borderRadius:"var(--radius-xl)",boxShadow:"var(--shadow-glass)",padding:16,color:"var(--fg-1)",textAlign:"left"},children:[u.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12},children:[u.jsxs("span",{style:{fontFamily:"var(--font-display)",fontStretch:"125%",fontWeight:800,fontSize:13,textTransform:"uppercase"},children:["Material",u.jsx("span",{style:{color:"var(--accent)"},children:"IQ"})]}),u.jsx(U,{verdict:e.verdict})]}),u.jsx("p",{style:{margin:"0 0 12px",fontSize:12,color:"var(--fg-2)",lineHeight:1.5},children:e.verdictCopy}),u.jsx("div",{style:{display:"grid",gap:10},children:o.map(l=>u.jsx(N,{label:l.label,value:l.value,max:l.max},l.key))}),u.jsx("a",{href:t,target:"_blank",rel:"noreferrer",style:{display:"block",fontSize:12,marginTop:12,color:"var(--accent)"},children:"Open full scorecard →"})]})]})}let g=null,v;const he=chrome.runtime.getURL("src/options/index.html")+"#methodology",ye=G.replace(/:root/g,":host");function be(){if(document.getElementById("miq-fonts"))return;const e=document.createElement("link");e.id="miq-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Archivo:wght@400..800&family=IBM+Plex+Mono:wght@400;500;600&display=swap",document.head.appendChild(e)}function xe(e){if(e==null)return null;const t=_(document),n=e.toFixed(2),i=t.querySelectorAll('span, div, p, b, strong, ins, bdi, [class*="price" i], [data-testid*="price" i], [itemprop="price"]');let r=null,s=1/0;for(const a of Array.from(i)){if(O(a,t))continue;const o=(a.textContent||"").replace(/\s+/g,"");!o||o.length>24||o.includes(n)&&o.length<s&&(r=a,s=o.length)}return r}let I=null;function R(){I?.(),I=null,document.getElementById("miq-badge-host")?.remove()}function ve(e){R(),be();const t=document.createElement("span");t.id="miq-badge-host",t.style.position="absolute",t.style.top="-9999px",t.style.zIndex="2147483647",document.body.appendChild(t);const n=t.attachShadow({mode:"open"}),i=document.createElement("style");i.textContent=ye+":host{all:initial;}",n.appendChild(i);const r=document.createElement("div");n.appendChild(r);const s=W(r);s.render(u.jsx(E.StrictMode,{children:u.jsx(ge,{analysis:e,docsUrl:he})}));const a=130,o=32;let c=null;const l=()=>{t.style.position="fixed",t.style.top=t.style.left="",t.style.right="20px",t.style.bottom="20px"},d=()=>{(!c||!c.isConnected)&&(c=xe(e.product.price));const m=c?.isConnected?c.getBoundingClientRect():null;if(m&&(m.width||m.height)&&window.innerWidth-m.right>a+16){t.style.position="absolute",t.style.right=t.style.bottom="";const w=window.scrollY+m.top+Math.max(0,(m.height-o)/2);let b=window.scrollX+m.right+10;b=Math.max(window.scrollX+8,Math.min(b,window.scrollX+window.innerWidth-a-8)),t.style.top=`${w}px`,t.style.left=`${b}px`}else l()};let f=0;const p=()=>{cancelAnimationFrame(f),f=requestAnimationFrame(d)};d();const h=[300,900,1800,3200].map(m=>window.setTimeout(d,m)),y=window.setInterval(d,2e3);window.addEventListener("scroll",p,{passive:!0}),window.addEventListener("resize",p,{passive:!0}),I=()=>{h.forEach(clearTimeout),clearInterval(y),window.removeEventListener("scroll",p),window.removeEventListener("resize",p),cancelAnimationFrame(f),s.unmount()}}async function C(e=0){const t=await Q(),n=le();if(!n||n.extractionConfidence<t.minConfidence){v=n?"low-confidence":"no-product",e<5&&!g&&setTimeout(()=>C(e+1),800);return}const i=$(n);if(g=i,chrome.runtime.sendMessage({type:"MIQ_VERDICT",verdict:i.verdict}).catch(()=>{}),t.showInlineBadge)try{ve(i)}catch(r){console.warn("[MaterialIQ] badge mount failed:",r)}t.reviewSummaries&&we(n)}async function we(e){const t=ue();if(t.length===0)return;const n=await de(e.title,t,e.url);if(!n)return;g=$({...e,reviews:n})}chrome.runtime.onMessage.addListener((e,t,n)=>e.type==="MIQ_GET_ANALYSIS"?(n({type:"MIQ_ANALYSIS",analysis:g,reason:v}),!0):(e.type==="MIQ_RECHECK"&&(R(),g=null,v=void 0,C().then(()=>n({type:"MIQ_ANALYSIS",analysis:g,reason:v}))),!0));let D=location.href;new MutationObserver(()=>{location.href!==D&&(D=location.href,g=null,v=void 0,R(),setTimeout(()=>C(),800))}).observe(document.body,{childList:!0,subtree:!0});C();
